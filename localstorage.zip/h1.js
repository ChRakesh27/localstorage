let list =[]
let int = document.querySelector("#input-el")
const sav = document.getElementById("Save-el")

const urltabs = document.getElementById("tabs-el")
const del = document.getElementById("Delete-el")

let ul = document.getElementById("ul-el")

let localStoragefeild =JSON.parse(localStorage.getItem("value"))
if(localStoragefeild){
    list = localStoragefeild
    rand(list)
}
urltabs.addEventListener("click",function(){

    chrome.tabs.query({active: true , currentWindow: true}, function(tabs){
        list.push(tabs[0].url)
        localStorage.setItem("value",JSON.stringify(list))
        rand(list)
        
    })
})
    sav.addEventListener("click", function(){
    list.push(int.value)
    localStorage.setItem("value",JSON.stringify(list))
    rand(list)
    int.value = ""
})
 
function rand(list){
    let totallist =""
    for(let i=0; i<list.length; i++){
        totallist += `<li> <a href='${list[i]}' target = '_blank'>  ${list[i]}  </a>  </li>`   
    }
    ul.innerHTML = totallist
}


del.addEventListener("dblclick", function(){
    list=[]
    console.log(list);
    localStorage.clear()
    rand(list)
})

